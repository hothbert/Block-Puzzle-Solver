The format of the 3 CSV files is
(<board>,<goal>,<impossible>)

The easy/medium/hard puzzles can be found in the relevant subdirectories.
